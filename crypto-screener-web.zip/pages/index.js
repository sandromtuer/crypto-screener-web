import { useEffect, useState } from "react";
import axios from "axios";

const SYMBOLS = [
  "BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT", "XRPUSDT", "DOGEUSDT",
  "ADAUSDT", "AVAXUSDT", "DOTUSDT", "TRXUSDT"
]; // Pode ser expandido

const getKlines = async (symbol, interval = "5m", limit = 200) => {
  const url = `https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`;
  const res = await axios.get(url);
  return res.data;
};

const calculateMA = (closes, period) => {
  const subset = closes.slice(-period);
  const sum = subset.reduce((acc, val) => acc + val, 0);
  return sum / period;
};

const calculateRSI = (closes, period = 14) => {
  let gains = 0, losses = 0;
  for (let i = closes.length - period; i < closes.length - 1; i++) {
    const diff = closes[i + 1] - closes[i];
    if (diff >= 0) gains += diff;
    else losses -= diff;
  }
  const rs = gains / (losses || 1);
  return 100 - 100 / (1 + rs);
};

export default function Home() {
  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const results = await Promise.all(
        SYMBOLS.map(async (symbol) => {
          try {
            const klines = await getKlines(symbol);
            const closes = klines.map(k => parseFloat(k[4]));
            const price = closes[closes.length - 1];
            const ma20 = calculateMA(closes, 20);
            const ma200 = calculateMA(closes, 200);
            const rsi = calculateRSI(closes);
            const volume = klines.map(k => parseFloat(k[5])).slice(-1)[0];
            let trend = "🔁";
            if (price > ma20 && price > ma200) trend = "🔼";
            else if (price < ma20 && price < ma200) trend = "🔽";

            return {
              symbol,
              price,
              ma20,
              ma200,
              rsi: rsi.toFixed(2),
              volume: volume.toFixed(0),
              trend
            };
          } catch (err) {
            return { symbol, error: true };
          }
        })
      );
      setData(results);
    };

    fetchData();
    const interval = setInterval(fetchData, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <main style={{ padding: "2rem", fontFamily: "Arial" }}>
      <h1 style={{ fontSize: "1.5rem", marginBottom: "1rem" }}>🟢 Crypto Screener - 5m</h1>
      <table border="1" cellPadding="10" style={{ borderCollapse: "collapse", width: "100%" }}>
        <thead>
          <tr>
            <th>Par</th>
            <th>Preço</th>
            <th>MA20</th>
            <th>MA200</th>
            <th>RSI</th>
            <th>Volume</th>
            <th>Tendência</th>
          </tr>
        </thead>
        <tbody>
          {data.map((item) => (
            <tr key={item.symbol} style={{ background: item.trend === "🔼" ? "#d4fcd4" : item.trend === "🔽" ? "#fcd4d4" : "#f0f0f0" }}>
              <td>{item.symbol}</td>
              <td>{item.price?.toFixed(2) || "-"}</td>
              <td>{item.ma20?.toFixed(2) || "-"}</td>
              <td>{item.ma200?.toFixed(2) || "-"}</td>
              <td>{item.rsi}</td>
              <td>{item.volume}</td>
              <td>{item.trend}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </main>
  );
}